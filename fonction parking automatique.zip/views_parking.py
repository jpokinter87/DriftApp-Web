"""
Vues API REST pour le mode parking et calibration.

À ajouter dans web/hardware/views.py ou créer un nouveau fichier.
"""
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

# Importer le client motor depuis views.py existant
# from .views import motor_client

# OU copier la définition du client ici si c'est un fichier séparé
import json
import uuid
from pathlib import Path
from django.conf import settings


class MotorServiceClient:
    """Client pour communiquer avec le Motor Service via fichiers IPC."""

    def __init__(self):
        self.command_file = Path(settings.MOTOR_SERVICE_IPC['COMMAND_FILE'])
        self.status_file = Path(settings.MOTOR_SERVICE_IPC['STATUS_FILE'])

    def send_command(self, command_type: str, **params) -> bool:
        """Envoie une commande au Motor Service."""
        command = {
            'id': str(uuid.uuid4()),
            'command': command_type,
            **params
        }
        try:
            self.command_file.write_text(json.dumps(command))
            return True
        except IOError:
            return False

    def get_motor_status(self) -> dict:
        """Lit le statut du Motor Service."""
        try:
            if self.status_file.exists():
                return json.loads(self.status_file.read_text())
        except (IOError, json.JSONDecodeError):
            pass
        return {'status': 'unknown', 'error': 'Motor Service non disponible'}


motor_client = MotorServiceClient()


class ParkView(APIView):
    """
    POST /api/hardware/park/

    Parque la coupole à la position de parking (44°).
    """

    def post(self, request):
        success = motor_client.send_command('park')

        if success:
            return Response({
                'message': 'Parking en cours...',
                'target': 44.0
            })
        else:
            return Response(
                {'error': 'Impossible de communiquer avec Motor Service'},
                status=status.HTTP_503_SERVICE_UNAVAILABLE
            )


class CalibrateView(APIView):
    """
    POST /api/hardware/calibrate/

    Calibre l'encodeur en passant par le switch (45°).
    """

    def post(self, request):
        success = motor_client.send_command('calibrate')

        if success:
            return Response({
                'message': 'Calibration en cours...',
                'target': 46.0
            })
        else:
            return Response(
                {'error': 'Impossible de communiquer avec Motor Service'},
                status=status.HTTP_503_SERVICE_UNAVAILABLE
            )


class EndSessionView(APIView):
    """
    POST /api/hardware/end-session/

    Termine la session d'observation.
    Arrête le suivi si actif et parque la coupole.
    """

    def post(self, request):
        success = motor_client.send_command('end_session')

        if success:
            return Response({
                'message': 'Fin de session - Parking en cours...',
                'target': 44.0
            })
        else:
            return Response(
                {'error': 'Impossible de communiquer avec Motor Service'},
                status=status.HTTP_503_SERVICE_UNAVAILABLE
            )


class ParkingStatusView(APIView):
    """
    GET /api/hardware/parking/status/

    Retourne l'état du mode parking et de la calibration encodeur.
    """

    def get(self, request):
        motor_status = motor_client.get_motor_status()

        return Response({
            'parking_enabled': motor_status.get('parking_enabled', True),
            'encoder_calibrated': motor_status.get('encoder_calibrated', False),
            'current_status': motor_status.get('status', 'unknown'),
            'position': motor_status.get('position', 0)
        })
