# 🅿️ Mode Parking - Guide d'intégration

## Vue d'ensemble

Le mode parking automatise la calibration de l'encodeur et le stationnement de la coupole avec une architecture adaptée aux nuits d'observation multi-objets.

### Architecture à 3 mécanismes

```
┌─────────────────────────────────────────────────────────────────┐
│  1. BOUTON "🌙 Fin de session" (action explicite)               │
│     → Arrête le suivi + Parking immédiat + Overlay visuel      │
└─────────────────────────────────────────────────────────────────┘
                              +
┌─────────────────────────────────────────────────────────────────┐
│  2. PARKING AU LEVER DU SOLEIL (automatique)                   │
│     → Calculé astronomiquement selon lat/lon du site           │
│     → Configurable : X minutes avant/après le lever            │
│     → Ne se déclenche QUE si un suivi a eu lieu dans la nuit  │
└─────────────────────────────────────────────────────────────────┘
                              +
┌─────────────────────────────────────────────────────────────────┐
│  3. VÉRIFICATION AU DÉMARRAGE (après extinction brutale)       │
│     → Warning si position ≠ zone parking (40-50°)              │
│     → L'utilisateur peut utiliser le bouton Parquer            │
└─────────────────────────────────────────────────────────────────┘
```

### Avantages

| Aspect | Bénéfice |
|--------|----------|
| **Multi-objets** | Pas de parking entre M13 → M57 → NGC 7000 |
| **Fin propre** | Bouton "Fin de session" pour parking explicite |
| **Filet de sécurité** | Parking auto au lever du soleil si oubli |
| **Adaptatif** | Heure calculée selon lat/lon et saison |

### Exemple pour Observatoire Ubik (lat 44.15°)

| Date | Lever du soleil | Parking auto (offset -15min) |
|------|-----------------|------------------------------|
| 21 juin | 05:52 | 05:37 |
| 21 décembre | 08:05 | 07:50 |
| 18 décembre | ~08:00 | ~07:45 |

## Fichiers fournis

| Fichier | Description |
|---------|-------------|
| `config_v2.3.json` | Configuration avec section parking |
| `motor_service_parking.py` | Motor Service avec mode parking |
| `views_parking.py` | Endpoints API Django |
| `dashboard_parking.js` | Code JavaScript frontend |
| `parking_buttons.html` | HTML des boutons parking |

---

## 1. Configuration (config.json)

Ajouter la section `parking` dans `data/config.json` :

```json
"parking": {
    "enabled": true,
    "switch_position": 45.0,
    "park_position": 44.0,
    "calibration_position": 46.0,
    "auto_park_on_stop": false,
    "auto_calibrate_on_start": true,
    "calibration_approach_direction": "cw",
    "sunrise_parking": {
        "enabled": true,
        "offset_minutes": -15,
        "only_if_session_active": true
    }
}
```

### Paramètres

| Paramètre | Type | Description |
|-----------|------|-------------|
| `enabled` | bool | Active/désactive le mode parking |
| `switch_position` | float | Position du switch de calibration (45°) |
| `park_position` | float | Position de parking (44°, avant le switch) |
| `calibration_position` | float | Position après calibration (46°, après le switch) |
| `auto_park_on_stop` | bool | **DÉSACTIVÉ** - Pas de parking entre objets |
| `auto_calibrate_on_start` | bool | Calibration automatique si encodeur non calibré |

### Paramètres sunrise_parking

| Paramètre | Type | Description |
|-----------|------|-------------|
| `enabled` | bool | Active le parking au lever du soleil |
| `offset_minutes` | int | Minutes avant (-) ou après (+) le lever. -15 = 15 min avant |
| `only_if_session_active` | bool | Ne parque que si un suivi a eu lieu cette nuit |

---

## 2. Motor Service (motor_service.py)

Remplacer `services/motor_service.py` par `motor_service_parking.py`.

### Nouvelles commandes IPC

| Commande | Description |
|----------|-------------|
| `park` | Parque la coupole à 44° |
| `calibrate` | Calibre l'encodeur (passe par 45°, arrêt à 46°) |
| `end_session` | **NOUVEAU** - Arrête le suivi + Parking |

### Nouveaux états

| Status | Description |
|--------|-------------|
| `parking` | Parking en cours |
| `calibrating` | Calibration en cours |

### Nouveaux champs dans motor_status.json

```json
{
    "encoder_calibrated": true,
    "parking_enabled": true
}
```

---

## 3. API Django

### Option A : Ajouter à `web/hardware/views.py`

```python
# Ajouter ces imports
from .views_parking import ParkView, CalibrateView, EndSessionView, ParkingStatusView

# Ajouter ces vues dans urls.py
urlpatterns = [
    # ... existants ...
    path('park/', ParkView.as_view(), name='park'),
    path('calibrate/', CalibrateView.as_view(), name='calibrate'),
    path('end-session/', EndSessionView.as_view(), name='end-session'),
    path('parking/status/', ParkingStatusView.as_view(), name='parking-status'),
]
```

### Option B : Copier directement dans views.py

Copier le contenu de `views_parking.py` à la fin de `web/hardware/views.py`.

### URLs (web/hardware/urls.py)

```python
from django.urls import path
from . import views

urlpatterns = [
    path('goto/', views.GotoView.as_view(), name='goto'),
    path('jog/', views.JogView.as_view(), name='jog'),
    path('stop/', views.StopView.as_view(), name='stop'),
    path('continuous/', views.ContinuousView.as_view(), name='continuous'),
    path('encoder/', views.EncoderView.as_view(), name='encoder'),
    path('status/', views.MotorStatusView.as_view(), name='motor-status'),
    # NOUVEAU : Mode parking
    path('park/', views.ParkView.as_view(), name='park'),
    path('calibrate/', views.CalibrateView.as_view(), name='calibrate'),
    path('end-session/', views.EndSessionView.as_view(), name='end-session'),
]
```

---

## 4. Frontend JavaScript

### Ajouter dans `dashboard.js`

Copier le contenu de `dashboard_parking.js` dans `dashboard.js`.

### Modifier `updateStatus()`

```javascript
async function updateStatus() {
    const { motor, encoder } = await fetchStatus();

    // ... code existant ...

    // AJOUTER :
    updateEncoderStatus(motor);
    updateParkingButtons(motor);
    
    // ... reste du code ...
}
```

### Modifier `updateServiceStatus()`

Ajouter les cas `parking` et `calibrating` :

```javascript
} else if (status === 'parking') {
    elements.statusDot.classList.add('moving');
    elements.statusText.textContent = '🅿️ Parking...';
} else if (status === 'calibrating') {
    elements.statusDot.classList.add('moving');
    elements.statusText.textContent = '🔧 Calibration...';
}
```

---

## 5. HTML des boutons

Ajouter dans le template HTML (section contrôle manuel) :

```html
<!-- Section Parking -->
<div class="control-section parking-section">
    <h3>🅿️ Parking</h3>
    
    <div class="parking-status">
        <span>Encodeur:</span>
        <span id="encoder-status" class="encoder-uncalibrated">⚠ Non calibré</span>
    </div>
    
    <div class="parking-buttons">
        <button id="btn-calibrate" class="btn btn-warning" title="Passer par le switch (45°) pour calibrer">
            🔧 Calibrer
        </button>
        <button id="btn-park" class="btn btn-secondary" title="Parquer à 44° (avant le switch)">
            🅿️ Parquer
        </button>
    </div>
</div>
```

### CSS suggéré

```css
.parking-section {
    margin-top: 1rem;
    padding: 1rem;
    background: rgba(0, 0, 0, 0.2);
    border-radius: 8px;
}

.parking-status {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.5rem;
}

.encoder-calibrated {
    color: #00d26a;
    font-weight: bold;
}

.encoder-uncalibrated {
    color: #ffa502;
    font-weight: bold;
}

.parking-buttons {
    display: flex;
    gap: 0.5rem;
}

.parking-buttons button {
    flex: 1;
}

.btn-warning {
    background: #ffa502;
    color: #000;
}

.btn-secondary {
    background: #6c757d;
    color: #fff;
}
```

---

## 6. Workflow utilisateur

### Début de session (automatique)

1. L'utilisateur démarre DriftApp
2. Le système vérifie si l'encodeur est calibré
3. **Si non calibré** : Calibration automatique (44° → 46° via 45°)
4. L'encodeur est maintenant calibré ✓
5. Le lever du soleil est calculé et affiché dans les logs

### Pendant la session (multi-objets possible)

1. L'utilisateur recherche un objet (ex: M13)
2. Clique sur "Démarrer le suivi"
3. Le système fait un GOTO automatique vers l'azimut cible
4. Le suivi démarre
5. **Pour changer d'objet** : Arrêter le suivi → Choisir nouvel objet → Démarrer
   - **Pas de parking entre les objets !**

### Fin de session (3 scénarios)

#### Scénario 1 : Fin propre (recommandé)
1. L'utilisateur clique sur "🌙 Fin de session"
2. Overlay "Parking en cours..." s'affiche
3. Le suivi s'arrête, la coupole parque à 44°
4. Message "Session terminée - Vous pouvez éteindre"

#### Scénario 2 : Oubli (filet de sécurité)
1. L'utilisateur ferme le navigateur et va dormir
2. Au lever du soleil (calculé) : parking automatique
3. La coupole est parkée pour le lendemain

#### Scénario 3 : Extinction brutale
1. Coupure de courant ou extinction sans parking
2. Au prochain démarrage : warning "Coupole hors zone parking"
3. L'utilisateur peut utiliser le bouton "Parquer"

---

## 7. Procédure de déploiement

```bash
cd ~/Dome_v4_6

# 1. Sauvegarde
mkdir -p backups/pre_parking
cp services/motor_service.py backups/pre_parking/
cp data/config.json backups/pre_parking/
cp web/hardware/views.py backups/pre_parking/
cp web/static/js/dashboard.js backups/pre_parking/

# 2. Copier les nouveaux fichiers
cp motor_service_parking.py services/motor_service.py
cp config_v2.3.json data/config.json

# 3. Ajouter les vues parking (copier le contenu à la fin de views.py)
cat views_parking.py >> web/hardware/views.py

# 4. Mettre à jour urls.py (ajouter les routes)
# Éditer manuellement web/hardware/urls.py

# 5. Mettre à jour le JavaScript
# Ajouter le contenu de dashboard_parking.js dans dashboard.js

# 6. Mettre à jour le template HTML
# Ajouter les boutons parking dans le template

# 7. Redémarrer
sudo ./start_web.sh restart
```

---

## 8. Tests de validation

| Test | Résultat attendu |
|------|------------------|
| Démarrage avec encodeur non calibré | Calibration automatique (44→46 via 45) |
| Démarrage avec encodeur calibré | Pas de calibration |
| Arrêt du suivi | **Pas de parking** (permet multi-objets) |
| Bouton "Fin de session" | Overlay + Parking vers 44° |
| Bouton "Calibrer" | Va à 46° en passant par 45° |
| Bouton "Parquer" | Va à 44° |
| État encodeur affiché | ✓ Calibré / ⚠ Non calibré |
| Au lever du soleil (si suivi actif) | Parking automatique |
| Démarrage après extinction brutale | Warning si hors zone parking |

### Test du calcul lever du soleil

Dans les logs au démarrage, vérifier :
```
🌅 Lever du soleil: 08:05 | Parking auto prévu: 07:50
```

Pour tester sans attendre le lever du soleil, modifier temporairement l'offset :
```json
"sunrise_parking": {
    "offset_minutes": -600  // 10h avant = maintenant si nuit
}
```

---

## 9. Désactivation du mode parking

Pour désactiver temporairement le parking automatique, modifier `config.json` :

```json
"parking": {
    "enabled": false,
    ...
}
```

Ou désactiver uniquement certaines fonctions :

```json
"parking": {
    "enabled": true,
    "auto_calibrate_on_start": false,  // Pas de calibration auto
    "sunrise_parking": {
        "enabled": false               // Pas de parking au lever du soleil
    }
}
```

---

## 10. Rollback

En cas de problème :

```bash
cp backups/pre_parking/motor_service.py services/
cp backups/pre_parking/config.json data/
cp backups/pre_parking/views.py web/hardware/
cp backups/pre_parking/dashboard.js web/static/js/
sudo ./start_web.sh restart
```

---

## 11. Calcul du lever du soleil

Le calcul utilise l'algorithme NOAA simplifié (précision ~1 minute) :
- Basé sur la latitude et longitude du site (config.json)
- S'adapte automatiquement aux saisons
- Prend en compte le fuseau horaire local

Pour l'Observatoire Ubik (lat 44.15°, lon 5.23°) :
- Solstice d'été : lever ~05:50
- Solstice d'hiver : lever ~08:05
- Équinoxes : lever ~07:00

---

**Dernière mise à jour** : 18 décembre 2025 - Version avec parking au lever du soleil
