// =========================================================================
// MODE PARKING - À ajouter dans dashboard.js
// =========================================================================

// Ajouter ces éléments DOM dans initElements()
// elements.btnPark = document.getElementById('btn-park');
// elements.btnCalibrate = document.getElementById('btn-calibrate');
// elements.btnEndSession = document.getElementById('btn-end-session');
// elements.encoderStatus = document.getElementById('encoder-status');

// Ajouter ces listeners dans initEventListeners()
// if (elements.btnPark) elements.btnPark.addEventListener('click', parkDome);
// if (elements.btnCalibrate) elements.btnCalibrate.addEventListener('click', calibrateDome);
// if (elements.btnEndSession) elements.btnEndSession.addEventListener('click', endSession);

/**
 * Parque la coupole à la position 44° (avant le switch).
 */
async function parkDome() {
    log('🅿️ Parking de la coupole...', 'info');
    const result = await apiCall('/api/hardware/park/', 'POST');

    if (result.error) {
        log(`Erreur parking: ${result.error}`, 'error');
    } else {
        log('🅿️ Parking en cours vers 44°...', 'info');
    }
}

/**
 * Calibre l'encodeur en passant par le switch (45°).
 */
async function calibrateDome() {
    log('🔧 Calibration de l\'encodeur...', 'info');
    const result = await apiCall('/api/hardware/calibrate/', 'POST');

    if (result.error) {
        log(`Erreur calibration: ${result.error}`, 'error');
    } else {
        log('🔧 Calibration en cours (passage par 45°)...', 'info');
    }
}

/**
 * Termine la session d'observation.
 * Arrête le suivi et parque la coupole.
 */
async function endSession() {
    // Confirmation
    if (!confirm('Terminer la session et parquer la coupole ?')) {
        return;
    }
    
    log('🌙 Fin de session demandée...', 'info');
    
    // Afficher l'overlay de fin de session
    showEndSessionOverlay();
    
    const result = await apiCall('/api/hardware/end-session/', 'POST');

    if (result.error) {
        log(`Erreur fin de session: ${result.error}`, 'error');
        hideEndSessionOverlay();
    } else {
        log('🌙 Parking en cours - Veuillez patienter...', 'info');
        // L'overlay sera masqué quand le status passera à 'idle'
    }
}

/**
 * Affiche l'overlay de fin de session pendant le parking.
 */
function showEndSessionOverlay() {
    let overlay = document.getElementById('end-session-overlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'end-session-overlay';
        overlay.innerHTML = `
            <div class="end-session-content">
                <div class="end-session-icon">🌙</div>
                <div class="end-session-title">Fin de session</div>
                <div class="end-session-message">Parking en cours...</div>
                <div class="end-session-spinner"></div>
            </div>
        `;
        document.body.appendChild(overlay);
    }
    overlay.classList.add('visible');
}

/**
 * Masque l'overlay de fin de session.
 */
function hideEndSessionOverlay() {
    const overlay = document.getElementById('end-session-overlay');
    if (overlay) {
        // Afficher le message de confirmation avant de masquer
        const message = overlay.querySelector('.end-session-message');
        const spinner = overlay.querySelector('.end-session-spinner');
        if (message) message.textContent = 'Session terminée - Vous pouvez éteindre';
        if (spinner) spinner.style.display = 'none';
        
        // Masquer après 3 secondes
        setTimeout(() => {
            overlay.classList.remove('visible');
        }, 3000);
    }
}

/**
 * Met à jour l'indicateur d'état de l'encodeur.
 * À appeler dans updateStatus() après avoir récupéré le motor status.
 * 
 * @param {Object} motor - Status du motor service
 */
function updateEncoderStatus(motor) {
    const encoderStatus = document.getElementById('encoder-status');
    if (!encoderStatus) return;

    const isCalibrated = motor.encoder_calibrated || false;
    
    if (isCalibrated) {
        encoderStatus.textContent = '✓ Calibré';
        encoderStatus.className = 'encoder-calibrated';
    } else {
        encoderStatus.textContent = '⚠ Non calibré';
        encoderStatus.className = 'encoder-uncalibrated';
    }
}

/**
 * Met à jour l'état des boutons parking selon le status.
 * À appeler dans updateStatus().
 * 
 * @param {Object} motor - Status du motor service
 */
function updateParkingButtons(motor) {
    const btnPark = document.getElementById('btn-park');
    const btnCalibrate = document.getElementById('btn-calibrate');
    const btnEndSession = document.getElementById('btn-end-session');
    
    const status = motor.status || 'unknown';
    const isMoving = ['parking', 'calibrating', 'moving', 'tracking'].includes(status);
    
    if (btnPark) {
        btnPark.disabled = isMoving;
        btnPark.classList.toggle('active', status === 'parking');
    }
    
    if (btnCalibrate) {
        btnCalibrate.disabled = isMoving;
        btnCalibrate.classList.toggle('active', status === 'calibrating');
    }
    
    if (btnEndSession) {
        btnEndSession.disabled = isMoving && status !== 'parking';
    }
    
    // Masquer l'overlay de fin de session quand le parking est terminé
    if (status === 'idle') {
        const overlay = document.getElementById('end-session-overlay');
        if (overlay && overlay.classList.contains('visible')) {
            hideEndSessionOverlay();
        }
    }
}

// =========================================================================
// MODIFICATION de updateStatus() - Ajouter ces lignes
// =========================================================================

/*
async function updateStatus() {
    const { motor, encoder } = await fetchStatus();

    // ... code existant ...

    // AJOUTER CES LIGNES:
    updateEncoderStatus(motor);
    updateParkingButtons(motor);
    
    // ... reste du code ...
}
*/

// =========================================================================
// MODIFICATION de updateServiceStatus() - Ajouter les états parking/calibrating
// =========================================================================

/*
function updateServiceStatus(motor, encoder) {
    const status = motor.status || 'unknown';

    elements.statusDot.className = 'status-dot';
    
    if (status === 'idle' || status === 'tracking') {
        elements.statusDot.classList.add('connected');
        elements.statusText.textContent = status === 'tracking' ? 'Suivi actif' : 'Connecté';
    } else if (status === 'moving') {
        elements.statusDot.classList.add('moving');
        elements.statusText.textContent = 'En mouvement';
    } else if (status === 'parking') {
        elements.statusDot.classList.add('moving');
        elements.statusText.textContent = '🅿️ Parking...';
    } else if (status === 'calibrating') {
        elements.statusDot.classList.add('moving');
        elements.statusText.textContent = '🔧 Calibration...';
    } else if (status === 'error') {
        elements.statusDot.classList.add('disconnected');
        elements.statusText.textContent = 'Erreur';
    } else {
        elements.statusText.textContent = 'Déconnecté';
    }
}
*/
